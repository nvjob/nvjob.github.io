Aim Desktop 0.0.1.3

-----------------------------------

Work more efficiently on your projects with the help of this lightweight and utility that displays various useful visual guides on your computer's screen.

Working on 3D modeling or CAD projects as well as other types of visual jobs for extended periods of time can put a fair bit of strain on your eyes, especially if you're dealing with apps with complex GUIs.

Loss of the ability to concentrate which, in turn, might lead to reduced visual orientation is just one of the effects that can be experienced by most users at a particular point.

It's in situations like these that Aim Desktop is sure to come in handy. In just a few words, this simplistic yet useful application has the potential to help you improve your workflow and your focus by displays a set of interesting visual guides or marks on your computer's screen.

Helps you better focus on your projects with the aid of a typical 2x2 grid and a goal-ruler.

Basically, you are provided with two types of visual references, namely a 2x2 grid (with four equally sized squares inside a larger one) and a sort of goal-ruler, let's call it that. There are three dimensions available for the grid, namely 606x606, 406x406, and 206x206, while the ruler can be displayed both horizontally or vertically. Quite conveniently, Aim Desktop provides you with the option to keep the visual aids on top of all the windows at all times, an option that can be enabled or disabled from the app's taskbar menu.

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob