ESFS Easy Soundbar for Streaming 1.0.0.1

-----------------------------------

Easy Soundbar for Streaming is a small program for playing various sounds by pressing hot keys.
This program was specially developed for streamers.

The program has three modes of operation:
- Playback of audio files (mp.3), a maximum of 20 files, two playlists.
- Midi piano, a simple piano for 7 notes and 2 sound signals (low and high frequency).
- The program reads the prepared text, up to 10 prepared phrases, the phrases can be changed while the program is running.

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob