CW Frame 0.0.1.5

-----------------------------------

CW Frame is a free program for quickly and easily creating desktop WEB applications based on the Chrome browser.
CW Frame forms a window from the Chrome browser itself, the main advantages of this approach are the small size of the application (4500kb), the ability to use the Google API without the Google API Key (for example, voice recognition), the ability to create an application from almost any site.

CW Frame features:
- Set any size of the application window.
- Make a fixed application window size.
- Place the application window in a specific place on the screen.
- Lock the movement of the application window.
- Place your application at the top of all windows.
- Make the application window transparent.
- Make a full-screen application, kiosk mode.
- Make the application anonymous, without history and cache, incognito mode.
- Check the connection to the site before running the application and while the application is running.
- Check the quality of the connection to the server where the application is located.
- The zoom of the application window is blocked, including the mouse wheel.
- Locked chrome hot keys.
- Disable the context menu by right-clicking in your application.
- Notifications about problems that occur (for example, loss of connection to the server).

All of the above features, in various combinations, allow you to create both your own web applications, and make a widget or application from any site.

-----------------------------------

CW Frame Instruction
http://nvjob.dx.am/board/-nvjob-apps/cw-frame/cw-frame-instruction-14_2.html

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob