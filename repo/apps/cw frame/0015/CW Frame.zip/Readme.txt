CW Frame 0.0.1.5
https://nvjob.github.io/apps/cw-frame

-----------------------------------

CW Frame is a free program for quickly and easily creating desktop WEB applications based on the Chrome browser.
CW Frame forms a window from the Chrome browser itself, the main advantages of this approach are the small size of the application (4500kb), the ability to use the Google API without the Google API Key (for example, voice recognition), the ability to create an application from almost any site.

-----------------------------------

Donate.
You can help this application by making a sponsorship donation.
https://nvjob.github.io/patrons

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io
