Lite Explorer 1.0.0.3
https://nvjob.github.io/apps/lite-eplorer

-----------------------------------

File manager for 2 windows + notes.

-----------------------------------

Donate.
You can help this application by making a sponsorship donation.
https://nvjob.github.io/patrons

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io
