Lite Explorer 1.0.0.3

-----------------------------------

File manager for 2 windows + notes.

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob