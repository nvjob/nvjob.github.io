Rain CPU Benchmark 0.0.1.4
https://rainbenchmark.pro

-----------------------------------

Multithreaded CPU Benchmark. The principle of this test is to run several single-threaded processes performing complex mathematical calculations that load a single CPU thread by 100%. In the composition of 10 tests: 1T (1 process), 2T, 4T, 6T, 8T, 12T, 16T, 24T, 32T, 64T (64 processes).

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob