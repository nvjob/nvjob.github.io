Rain CPU Benchmark 0.0.1.4
https://nvjob.github.io/apps/rain-cpu-benchmark

-----------------------------------

Multithreaded CPU Benchmark. The principle of this test is to run several single-threaded processes performing complex mathematical calculations that load a single CPU thread by 100%. In the composition of 10 tests: 1T (1 process), 2T, 4T, 6T, 8T, 12T, 16T, 24T, 32T, 64T (64 processes).

-----------------------------------

Donate.
You can help this application by making a sponsorship donation.
https://nvjob.github.io/patrons

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io
