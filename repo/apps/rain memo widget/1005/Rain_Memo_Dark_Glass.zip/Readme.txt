Rain Memo Widget 1.0.0.5
https://nvjob.github.io/apps/rain-memo

-----------------------------------

Rain Memo - widget, scrapbook on the desktop.
The note is immediately saved and will not disappear after the widget is closed.
The widget can be mounted on top of all programs windows.
You can enable or disable the autoloading of the widget along with the operating system.
Different skins for widget design.

Why I did not combine all the skins into one widget. Because practice shows that no one changes the skin of a widget constantly, usually the same skin is used regularly.

-----------------------------------

Donate.
You can help this application by making a sponsorship donation.
https://nvjob.github.io/patrons

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io
