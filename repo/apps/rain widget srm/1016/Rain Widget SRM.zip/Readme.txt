Rain Widget SRM 1.0.1.6
https://nvjob.github.io/apps/rain-widget-srm

-----------------------------------

Text-to-Speech. This widget reads any selected text by voice. Also control the volume.

-----------------------------------

Donate.
You can help this application by making a sponsorship donation.
https://nvjob.github.io/patrons

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io
