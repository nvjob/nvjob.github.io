Rain Widget SRM 1.0.1.6

-----------------------------------

Text-to-Speech. This widget reads any selected text by voice. Also control the volume.

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob