VirtualBox Hide 1.0.0.2
https://nvjob.github.io/apps/virtualbox-hide

-----------------------------------

A small utility that allows you to hide VirtualBox virtual machine windows from the desktop and taskbar.
It is very inconvenient to work at the desktop, on which there are 3, 4 or 7 windows with running virtual machines.
VirtualBox Hide allows you to hide the windows of virtual machines with the processes running on them and continue to work normally, at their main desktop.

-----------------------------------

Donate.
You can help this application by making a sponsorship donation.
https://nvjob.github.io/patrons

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io
