Rain Voice Memo 1.0.1.5

-----------------------------------

A utility for cyclical reminder of any event. The utility displays a text message and reads it in a voice.
This utility can serve as a motivator. For example, you spend a lot of time at the computer, you can set up the utility so that every hour, she told you, for example, to go like, play sports, etc ..

-----------------------------------

Designed by #NVJOB Nicholas Veselov
nvjob.pro | nvjob.dx.am | github.com/nvjob