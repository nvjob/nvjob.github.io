Rain Voice Note 1.0.0.3

-----------------------------------

Voice notepad for typing using voice.
This is an open source WEB application made using CW Frame (https://nvjob.github.io/apps/cw-frame).
Voice recognition is implemented using the Google Cloud Speech API (https://cloud.google.com/speech-to-text).

-----------------------------------

Designed by #NVJOB Nicholas Veselov
https://nvjob.github.io